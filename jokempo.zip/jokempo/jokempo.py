# Pedra, papel, tesoura

import random
import time

print('=-='*10)
print('           JOKEMPÔ')
print('-'*30)

print('[1] PEDRA')
print('[2] PAPEL')
print('[3] TESOURA')

jogador = int(input('Escolha uma opção: '))
opcoes = ['PEDRA', 'PAPEL', 'TESOURA']
computador = random.choice(opcoes)

if jogador < 1 or jogador > 3:
    print('Opção inválida!')

if jogador == 1 and computador == 'PEDRA':
    print('Ambos escolheram PEDRA.')
    print('Empate!')
elif jogador == 1 and computador == 'PAPEL':
    print('Você escolheu PEDRA e o computador {}.'.format(computador))
    print('PAPEL embrulha a PEDRA. Você pedreu!')
elif jogador == 1 and computador == 'TESOURA':
    print('Você escolheu PEDRA e o computador {}.'.format(computador))
    print('PEDRA quebra a TESOURA. Você ganhou!')


if jogador == 2 and computador == 'PEDRA':
    print('Você escolheu PAPEL e o computador {}.'.format(computador))
    print('PAPEL embrulha a PEDRA. Você ganhou!')
elif jogador == 2 and computador == 'PAPEL':
    print('Ambos escolheram PAPEL.')
    print('Empate!')
elif jogador == 2 and computador == 'TESOURA':
    print('Você escolheu PAPEL e o computador {}.'.format(computador))
    print('TESOURA corta o PAPEL. Você perdeu!')


if jogador == 3 and computador == 'PEDRA':
    print('Você escolheu TESOURA e o computador {}.'.format(computador))
    print('PEDRA quebra a TESOURA. Você perdeu!')
elif jogador == 3 and computador == 'PAPEL':
    print('Você escolheu TESOURA e o computador {}.'. format(computador))
    print('TESOURA corta o PAPEL. Você ganhou!')
elif jogador == 3 and computador == 'TESOURA':
    print('Ambos escolheram TESOURA.')
    print('Empate!')

print('')
print('O jogo será encerrado em 5 segundos.')
time.sleep(5)
